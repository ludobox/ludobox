
	</div>
</div>
<footer id="about">
	<div class="container">
		<p class="to-top"><a href="#header">Back to top</a></p>
		<h2>About PirateBox</h2>
		<p>Inspired by pirate radio and the free culture movement, PirateBox is a self-contained mobile collaboration and file sharing device. PirateBox utilizes Free, Libre and Open Source software (FLOSS) to create mobile wireless file sharing networks where users can anonymously share images, video, audio, documents, and other digital content.</p>
		<p>PirateBox is designed to be safe and secure. No logins are required and no user data is logged. The system is purposely not connected to the Internet in order to prevent tracking and preserve user privacy.</p>
		<small>PirateBox is licensed under GPLv3.</small>
	</div>
</footer>
